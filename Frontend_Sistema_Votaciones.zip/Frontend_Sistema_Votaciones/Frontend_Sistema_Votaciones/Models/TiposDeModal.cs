﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Frontend_Sistema_Votaciones.Models
{
    public class TiposDeModal
    {
        public const string Nuevo = "Nuevo";
        public const string Editar = "Editar";
        public const string Eliminar = "Eliminar";
    }
}
