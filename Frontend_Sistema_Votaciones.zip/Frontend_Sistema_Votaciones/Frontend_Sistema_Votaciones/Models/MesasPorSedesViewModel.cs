﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Frontend_Sistema_Votaciones.Models
{
    class MesasPorSedesViewModel
    {

        public int MePS_Id { get; set; }
        public int Mesa_Id { get; set; }
        public int Sede_Id { get; set; }

    }
}
