﻿using System;

namespace Sistema_Votaciones.Common
{
    public class Class1
    {
    }
}
