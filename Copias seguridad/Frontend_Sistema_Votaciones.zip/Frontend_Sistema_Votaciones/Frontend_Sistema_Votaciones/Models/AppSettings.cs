﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Frontend_Sistema_Votaciones.Models
{
    public class AppSettings
    {
        public string BaseAddress { get; set; }
    }
}
