﻿using System;

namespace Sistema_Votaciones.DataAcess
{
    public class Class1
    {
    }
}
