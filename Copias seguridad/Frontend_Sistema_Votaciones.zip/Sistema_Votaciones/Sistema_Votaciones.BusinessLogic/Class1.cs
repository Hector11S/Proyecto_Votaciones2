﻿using System;

namespace Sistema_Votaciones.BusinessLogic
{
    public class Class1
    {
    }
}
