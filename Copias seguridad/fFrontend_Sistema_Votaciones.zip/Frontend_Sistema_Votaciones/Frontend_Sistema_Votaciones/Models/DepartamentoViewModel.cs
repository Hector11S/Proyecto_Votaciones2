﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Frontend_Sistema_Votaciones.Models
{
    public class DepartamentoViewModel
    {
        public string Dept_Codigo { get; set; }
        public string Dept_Descripcion { get; set; }
    }    
}
