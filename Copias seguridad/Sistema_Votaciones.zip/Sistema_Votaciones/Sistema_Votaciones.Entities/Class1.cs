﻿using System;

namespace Sistema_Votaciones.Entities
{
    public class Class1
    {
    }
}
